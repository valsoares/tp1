var class_valor_minimo =
[
    [ "getValorMinimo", "class_valor_minimo.html#a28938ba9d6b221db122d45b00643cc56", null ],
    [ "setValorMinimo", "class_valor_minimo.html#a81fd7fc9dfee21b427a2c1bba28da2fa", null ]
];