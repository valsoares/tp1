var class_codigo_banco =
[
    [ "getCodigoBanco", "class_codigo_banco.html#a16ee27e0be4cd807b70870da281a4859", null ],
    [ "setCodigoBanco", "class_codigo_banco.html#a6fddccf7c49300efc36985ffbaa33fd8", null ]
];