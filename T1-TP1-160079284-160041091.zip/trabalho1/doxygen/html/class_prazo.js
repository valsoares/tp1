var class_prazo =
[
    [ "getPrazo", "class_prazo.html#a46fb711854724a89cc7775596937ec63", null ],
    [ "setPrazo", "class_prazo.html#a5247e6e7338ec842bd6003e4ea42541d", null ]
];