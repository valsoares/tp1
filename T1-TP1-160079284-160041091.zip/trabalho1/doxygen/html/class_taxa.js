var class_taxa =
[
    [ "getTaxa", "class_taxa.html#abb234d96a0d46bdde7ccd5e244e4b020", null ],
    [ "setTaxa", "class_taxa.html#a3aac75ab6285881f4757ea01bef05479", null ]
];