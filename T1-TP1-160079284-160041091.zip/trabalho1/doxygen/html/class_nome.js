var class_nome =
[
    [ "getNome", "class_nome.html#aad41176173eec20cbbae1576447a3697", null ],
    [ "setNome", "class_nome.html#a83b9f56ec9f86f4b976846f4c5c65b30", null ]
];