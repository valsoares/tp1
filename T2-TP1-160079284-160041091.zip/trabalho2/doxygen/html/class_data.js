var class_data =
[
    [ "getData", "class_data.html#afc7b15a5e81334858e48709b2f45cdc3", null ],
    [ "setData", "class_data.html#a5245638838a033c98a8b760836dddb7d", null ]
];