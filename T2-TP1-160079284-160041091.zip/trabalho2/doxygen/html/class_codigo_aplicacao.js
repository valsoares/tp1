var class_codigo_aplicacao =
[
    [ "getCodigoAplicacao", "class_codigo_aplicacao.html#aa3566ae14ea0b2e783d03e5786e04dcc", null ],
    [ "setCodigoAplicacao", "class_codigo_aplicacao.html#a8feb1336fc3ca5990a981a6ac9422de2", null ]
];