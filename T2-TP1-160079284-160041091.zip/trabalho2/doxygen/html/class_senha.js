var class_senha =
[
    [ "getSenha", "class_senha.html#a8786b3d03b1652e73df1cdce46cbbaaf", null ],
    [ "setSenha", "class_senha.html#a8d8c97b325a445bd40c375627ed81e25", null ]
];