var class_cpf =
[
    [ "getCpf", "class_cpf.html#a902324865e17495f9633edd23ed02cd9", null ],
    [ "setCpf", "class_cpf.html#a5a0d34c779b2573e7cc38e1df1db1832", null ]
];