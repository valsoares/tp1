var class_codigo_produto =
[
    [ "getCodigoProduto", "class_codigo_produto.html#ac85628b43ff61fe78758ccb4f06f2183", null ],
    [ "setCodigoProduto", "class_codigo_produto.html#a9dc1e42fd4327e0026dcc3e56bf77acb", null ]
];