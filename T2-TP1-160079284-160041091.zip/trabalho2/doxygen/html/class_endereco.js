var class_endereco =
[
    [ "getEndereco", "class_endereco.html#aa1ccbda52f9559a68379c54e7e914d19", null ],
    [ "setEndereco", "class_endereco.html#a36e8c19c5e97f321d77aece5b3e53239", null ]
];