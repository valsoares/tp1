var class_classe =
[
    [ "getClasse", "class_classe.html#ac10b1d41b5435be0d15b6770e3d0c626", null ],
    [ "setClasse", "class_classe.html#a7bad184eebd2ec1b76ca70869d0cfc9c", null ]
];