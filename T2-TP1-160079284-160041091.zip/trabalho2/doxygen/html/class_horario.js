var class_horario =
[
    [ "getHorario", "class_horario.html#a48bafd16811951544db6244ddc17e2ab", null ],
    [ "setHorario", "class_horario.html#abbf8d4352a311a9632e2aa0dfe017d93", null ]
];